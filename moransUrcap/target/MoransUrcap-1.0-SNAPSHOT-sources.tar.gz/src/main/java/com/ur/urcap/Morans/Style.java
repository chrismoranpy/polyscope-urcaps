package com.ur.urcap.Morans;

import java.awt.Dimension;

public abstract class Style {

	public abstract int getVerticalSpacing();

	public abstract int getHorizontalIndent();

	public abstract Dimension getButtonSize();

}
